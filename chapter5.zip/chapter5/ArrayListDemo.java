package com.cg.chapter5;
 
import java.io.ObjectInputStream.GetField;
import java.util.ArrayList;
import java.util.List;

public class ArrayListDemo {
	public static void main(String[] args) {
		List<String> c = new ArrayList<String>(); // create an ArrayList, c
		c.add("Oslo"); // add original cities
		c.add("Paris");
		c.add("Rome");
		c.add("Rome");
		c.add("Italy");
		c.add(1,"North");
		c.add(2, "South");
		//c.clear();
		int index = c.indexOf("Paris"); // find Paris' index
		System.out.println(c + " " + index);
		c.add(index, "London"); // add London before Paris
		System.out.println(c);// we're telling compiler to invoke toString methhod.
		System.out.println(c.contains("Rome")+" "+c.contains("Japan"));
		System.out.println("Get string at 1st position: "+c.get(3));
		System.out.println(c.remove(4));
		System.out.println(c);
		System.out.println("Size : "+c.size()+ " "+ "Content :"+c);
		
	}
}
