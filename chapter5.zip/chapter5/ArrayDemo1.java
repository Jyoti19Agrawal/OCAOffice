package com.cg.chapter5;


interface Sporty {
	void beSporty();
	}
	class Ferrari extends Car implements Sporty {
	public void beSporty() {
	// implement cool sporty method in a Ferrari-specific way
	}
	}
	class AthleticShoe{}
	class RacingFlats   implements Sporty {
	public void beSporty() {
	// implement cool sporty method in a RacingFlat-specific way
	}
	}
	class GolfClub extends RacingFlats { }
	
	class Car {
		int[] splats;
		int[] dats = new int[4];
		char[] letters = new char[5];
		/*splats  = dats; // OK, dats refers to an int array
		splats  = letters; // NOT OK, letters refers to a char array
		*/
	}
	class Subaru extends Car {}
public class ArrayDemo1 {

	public static void main(String[] args) { 
		int[] blots = new int[5];
		int[][] squeegees = new int[3][];
		int number = 4;
		//blots = squeegees; // CT 
		//squeegees [0] = number;
		squeegees [1] = blots;
			Sporty[] sportyThings = new Sporty [3];
			RacingFlats[] race = (RacingFlats[]) new Sporty[1];
			sportyThings[0] = new Ferrari(); // OK, Ferrari
			// implements Sporty
			sportyThings[1] = new RacingFlats(); // OK, RacingFlats
			// implements Sporty
			
			sportyThings[2] = new GolfClub(); // NOT ok..
			// Not OK; GolfClub does not implement Sporty
			// I don't care what anyone says
			 AthleticShoe[] ath =new AthleticShoe[3]; // not valid
			 Car [] car=new Car[2]; // not valid 
			 Ferrari[] f= new Ferrari[5];// valid because it implement the interface
			 sportyThings= f;
			

	}
}
