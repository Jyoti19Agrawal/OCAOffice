 

import java.util.Date;

public class Book {
	private String title; // instance reference variable
	private int width;
	private int height;
	static int [] year = new int[100];
	//Date date ;
	public Book(int k, int l) {
		// TODO Auto-generated constructor stub
		width = k;
		height = l;
	}

	public String getTitle() {
		return title;
	}

	public static void main(String[] args) {
		int x;
		Date date = null;
		int [] abc= {1,2,3,4,5};// agar object hi ni banaya or use karenge to null pointer exception
		//int [] abc= new int[5];
		Book b = new Book(5,10);
		String s = b.getTitle(); // Compiles and runs
		System.out.println(s);
		//String t = s.toLowerCase(); // Runtime Exception!
		if (s != null) {
			String t = s.toLowerCase();
			}
		for(int i=0;i<100;i++){
			System.out.println("year[" + i + "] = " + year[i]);
			}
		//System.out.println("Year="+year);
		
		args[0]="hello";
		
		if (args[1] != null) { // assume you know this is true
		x = 7; // compiler can't tell that this
		// statement will run
		System.out.println(args[1]+" "+args[0]+" "+x);
		}
		//int y = x; // the compiler will choke here
		
		
		if (date == null)// if you will use instance variable then use dot operator.
		System.out.println("date is null");
	
		
		for (int b1=0;b1<5;b1++)
		{
			System.out.println("abc["+b1+"]="+abc[b1]);
		}
	
		
		//Dimension a1 = new Dimension(5,10);
		System.out.println("a1.height = " + b.height);
		Book b1 = b;
		b1.height = 30;
		System.out.println("a1.height = " + b.height +
		" after change to b");
		
		
		String x1 = "Java"; // Assign a value to x
		String y = x1; // Now y and x refer to the same
		// String object
		System.out.println("y string = " + y);
		//x1 = x1.toUpperCase() + " Bean"; // Now modify the object using
		y.toUpperCase();
		// the x reference
		
	 
		System.out.println("y string = " + y);
	}	
}
