package com.jyoti.selftest5;

public class Tailor {
	public static void main(String[] args) {
		byte[][] ba = { { 1, 2, 3, 4 }, { 1, 2, 3 } };
		System.out.println(ba[1].length + " " + ba.length);
	}
}