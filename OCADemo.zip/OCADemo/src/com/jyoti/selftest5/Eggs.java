package com.jyoti.selftest5;

class Dozens {
	int[] dz = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12 };
}

public class Eggs {
	public static void main(String[] args) {
		Dozens[] da = new Dozens[3];
		da[0] = new Dozens();
		Dozens d = new Dozens();
		System.out.println(da);
		System.out.println(da[0]);
		System.out.println(d);
		System.out.println("*********************************************");
		da[1] = d;
		System.out.println(da[1]);
		System.out.println(d);
		System.out.println("*********************************************");
		d = null;
		//System.out.println(d);
		da[1] = null;
		//System.out.println(da[1]);
		// do stuff
		System.out.println(da);
		System.out.println(da[0]);
		System.out.println(d);
	}
}