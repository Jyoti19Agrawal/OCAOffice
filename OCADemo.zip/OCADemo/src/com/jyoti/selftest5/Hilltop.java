package com.jyoti.selftest5;

/*public class Hilltop {
 public static void main(String[] args) {
 String[] horses = new String[5];
 //horses[4] = null;
 System.out.println(args.length);
 for (int i = 0; i < horses.length; i++) {
 if (i < args.length)
 horses[i] = args[i];
 System.out.print(horses[i].toUpperCase() + " ");
 }
 }
 }*/

public class Hilltop {
	 
	public static void main(String[] args) {
		char c = 0x4e;
		System.out.println(c);
		char[] ca = { 0x4e, '\u004e', 78 };
		System.out.println((ca[0] == ca[1]) + " " + (ca[0] == ca[2]));
	}
}