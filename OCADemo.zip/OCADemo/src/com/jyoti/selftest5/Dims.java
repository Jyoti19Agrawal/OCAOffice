package com.jyoti.selftest5;

/*class Dims {
 public static void main(String[] args) {
 int[][] a = { { 1, 2 }, { 3, 4 } };
 int[] b = (int[]) a[1];
 Object o1 = a;
 int[][] a2 = (int[][]) o1;
 int[] b2 = (int[]) o1;
 System.out.println(b[1]);
 }
 }*/

import java.util.*;

public class Dims {
	public static void main(String[] args) {
		ArrayList<String> myList = new ArrayList<String>();
		myList.add("apple");
		myList.add("carrot");
		myList.add("banana");
		myList.add(1, "plum");
		System.out.print(myList);
	}
}