package com.jyoti.selftest4;

public class Cowboys {
	public static void main(String[] args) {
		int x = 12;
		int a = 5;
		int b = 7;
		System.out.println(x / a + " " + x / b);
	}
}
