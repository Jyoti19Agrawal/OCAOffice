package com.cg.selftest3;

public class Telescope {
	static int magnify = 2;

	public static void main(String[] args) {
		Telescope t = new Telescope();
		t.go();
		System.out.println(magnify);
	}

	 void go() {
		int magnify = 3;
		zoomIn();
		System.out.println(magnify);
	}

	 void zoomIn() {
		System.out.println(magnify);
		magnify *= 5;
		System.out.println(magnify);
		zoomMore(magnify);
		System.out.println(magnify);
	}

	 void zoomMore(int magnify) {
		magnify *= 7;
		System.out.println(magnify);
	}
}