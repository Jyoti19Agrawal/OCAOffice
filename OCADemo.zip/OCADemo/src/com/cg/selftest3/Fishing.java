package com.cg.selftest3;

/*public class Fishing {
 byte b1 = 4;
 int i1 = 123456;
 long L1 = (long) i1; // line A
 short s2 = (short) i1; // line B
 byte b2 = (byte) i1; // line C
 int i2 = (int) 123.456; // line D
 byte b3 = b1 + 7; // line E
 }*/

public class Fishing {
	public static void main(String[] args) {
		int i1 = 1_000; // line A
		int i2 = 10_00; // line B
		int i3 = _10_000; // line C
		int i4 = 0b101010; // line D
		int i5 = 0B10_1010; // line E
		int i6 = 0x2_a; // line F
	}
}