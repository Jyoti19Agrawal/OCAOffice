package com.cg.chapter4;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] key = new int[5];  
		//int key [];
		System.out.println(key);
	}

}
