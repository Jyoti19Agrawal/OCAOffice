package com.cg.chapter4;

public class ArrayDemo {

	int[] key = new int[5]; 
	int [] key1;
	String s1;
	String s2;
	
	
	public ArrayDemo() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ArrayDemo(String s1) {
		super();
		this.s1 = s1;
	}
	void takesAnArray(int[] someArray) {
		// use the array parameter
		for (int i = 0; i<someArray.length; i++)
		{
			System.out.println(someArray[i]);
		}
		}
 	public static void main(String[] args) {
		// TODO Auto-generated method stub
 		
		 System.out.println(new ArrayDemo().key1);// runtime exception
		//int key [];
		//System.out.println(key);
		int [] [] array = new int [3][2];
		int [][] array3= {{1,2,3},{4,5,7}};
		int [] array1= new int [2];
		/*int y = -5;
		System.out.println(array1[y]);*/
		char [] [] c =new char[3][];
		char a = 'A';
		char b = 'B';
		byte t = 15;
		byte v = (byte) (a+t);// otherwise CT error
		System.out.println(v);
		
		char c9 = (char) (a  + b);
		char [][] c1 = null ;
		System.out.println("a["+ array1[1]+ "]= "+array1[1]);
		System.out.println(c1);
		int [] [] array2 = new int [1][]; //valid but will throw null pointer exception
		array [0][0] = 2;
		array [0][1] = 4;	
		array [1][0] = 3;
		array [1][1] = 5;
		array [2][0] = 1;
		array [2][1] = 4;
		System.out.println(array [0][0]+ " " + array [1][0]);
		
		System.out.println(array3[0][1] + " "+ array3[1][2]);
		int p =0 ; 
		
		for(int i = 0; i < array3.length ; i++)
		{
			for(int j=0;j < array3[i].length; j++)
			{
				//System.out.println(array3.length);
				System.out.println(array3[i][j]);
			}
		}
		
		ArrayDemo arr = new ArrayDemo("Fluffy");
		ArrayDemo [][] demo  = {{new ArrayDemo("Zeus"), new ArrayDemo("Bilbo")}, {new ArrayDemo("Bert")}};
		//demo = demo[0];

		arr.takesAnArray(new int[] {7,7,8,2,5});
		int[][][] someArray;
		 
		
		int[] weightList = new int[5];
		byte b23 = 4;
		char c45 = 'c';
		short s = 7;
		long l = 123654L;
		weightList[0] = b23; // OK, byte is smaller than int
		weightList[1] = c45; // OK, char is smaller than int
		weightList[2] = s;
		//weightList[3] = l;// CT error otherwise cast it.
		System.out.println(weightList[1]);
	}

}
