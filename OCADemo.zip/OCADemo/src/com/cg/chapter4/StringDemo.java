package com.cg.chapter4;

public class StringDemo {

	 /*String s = new String  ("abcdef");
	String s2 = s;
	
	s = s.concat("More Stuff");*/
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder sb = new StringBuilder("abcdef ");
		StringBuilder sb1 = new StringBuilder();
		StringBuilder sb2 = new StringBuilder(10);
		sb.append("Added");
		sb1.append("Hello");
		sb2.append("Capgeminiiiiiiiiiii");
		int f1= sb2.capacity();
		int sb5 = sb1.capacity();
		System.out.println(sb5);
		System.out.println(sb1);
		System.out.println(sb2);
		System.out.println(f1);
		//sb.reverse();
		sb.insert(5,"ABCD");
		sb.delete(2, 4);
		System.out.println(sb);
		String s ="abcdef";
		 String s1 = new String  ("abcdef ");
			String s2 = s;
			s.concat("More Stuff");
			
		 
		//String x = null;
			String x = "Java ";
		String[] x1 = new String[3];
		System.out.println( x1.length);
		System.out.println( x.toString());
		
		x= x.toUpperCase();
		//x= x.trim();
		//x= x.concat(" Rules!");
		x = x.concat(s);
		//x = x.replace('A', 'X');
		boolean b = x.equalsIgnoreCase("Java abcdef");
		char c = x.charAt(2);
		System.out.println(x.substring(2));
		System.out.println(x.substring(2, 7));
		System.out.println(x.length());
		System.out.println(c);
		System.out.println(b);
		System.out.println(s);	
		System.out.println("x = " + x);
		
		
		
		/*StringDemo s1=new StringDemo();
		String y = s1.s;
		System.out.println(y);*/
	}

}
