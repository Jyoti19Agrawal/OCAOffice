package com.cg.chapter4;

class Special {
	//private StringBuilder s = new StringBuilder("bob"); // our special data
	String s1="Hello";
	private String s ="Bob";
	/*StringBuilder getName() {
		return s;
	}*/

	String printName() {
		//System.out.println(s);
		return s;
	} // verify our special
	// data
}

public class Encapsulation {

	public static void main(String[] args) {
		Special sp = new Special();
		//StringBuilder s2 = sp.getName();
		//s2.append("fred");
		String s1 = sp.printName();
		s1 = s1.concat("Fred");
		System.out.println(s1);
	}
}
