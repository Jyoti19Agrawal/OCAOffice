package com.cg.chapter6;

public class BreakDemo {

	private static final boolean EOF = false;

	public static void main(String[] args) {

		// boolean problem = false;
		int x = 0;
		int y = 0;
		for (; x < 4; x++) {
			if (x == 2) {
				System.out.println("There was a problem");
				continue;
			}
			System.out.println("Outside If statement");
			y++;
		}
		System.out.println("Outside while statement");
		System.out.println(y);

		/*
		 * while (!EOF) { boolean wrongField = false; // read a field from a
		 * file if (wrongField) { continue; // move to the next field in the
		 * file } System.out.println("continue with this statement"); //
		 * otherwise do other stuff with the field }
		 */

		// System.out.println("Outside while loop");

		System.out.println("**************************************");
		int y1 = 0;
		for (int x1 = 0; x1 < 4; x1++) {
			if (x1 == 2) {
				System.out.println("There was a problem");
				break;
			}
			System.out.println("Outside If statement");
			y1++;
		}
		System.out.println("Outside while statement");
		System.out.println(y1);

		
		int y2;
		foo:
			y2 = 9;
			for (int x1 = 3; x1 < 6; x1++) {
			while(y2 > 7) {
			System.out.println(y2--);
			continue
			;
			}
			System.out.println("Outside while");
			}
		
		
		boolean isTrue = true;
		outer: 
			for (int i = 0; i < 5; i++) {
			while (isTrue) {
				System.out.println("Hello");
				break outer;
			} // end of inner while loop
			System.out.println("Outer loop."); // Won't print
		} // end of outer for loop
		System.out.println("Good-Bye");

	}

}
