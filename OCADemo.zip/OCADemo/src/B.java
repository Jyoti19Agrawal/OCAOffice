 

class A {
}

class B extends A {
	public static void main(String[] args) {
		A myA = new B();
		B myB = new B();
		m2(myA, myB);
		
		String a = "Jyoti";
		//String a = null;
		A[] a1 = new B[3];
		boolean b = null instanceof String;
		boolean c = a instanceof String;
		boolean d = a1 instanceof A[];//instanceof is basically for object reference only always
		boolean e = a1 instanceof Object;// array is always an instance of object
		System.out.println(b + " " + c + " "+d + " "+e);
		
		
		int x = 15;
		int f = 20;
		int y = f % 4;//result is remainder
		int z = f / 4;
		System.out.println("The result of 15 % 4 is the "
		+ "remainder of 15 divided by 4. The remainder is " + y + " " + z);
		//System.out.println();
		
		
		String s = "String";
		String s1 = "Java";
		int b1 = 3;
		int c1 = 7;
		System.out.println(s +" "+ (s1+ b1));
	}

	public static void m2(A a, B b) {
		if (a instanceof B)
			((B) a).doBstuff(); // downcasting an A reference
			// to a B reference
		if(b instanceof B){
			b.doBstuff();
		System.out.println("'b' refers to a object");
		}
	}

	public static void doBstuff() {
		System.out.println("'a' refers to a B");
		
	}
}