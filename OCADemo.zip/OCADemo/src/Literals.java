 

class Octal {

}

class Literals {

	// Integer Literal
	int pre7 = 1000000; // confuse kr rha hai
	int length = 346; // decimal literal
	int with7 = 1_000_000; // readable

	// int i1 = _1_000_000; // illegal, can't begin with an "_"
	int i2 = 10_0000_0; // legal, but confusing

	float f = 12345.456f; // 32 bit
	double d = 235647;
	double d1 = 2345.6785; // 64 bit
	float f1 = 1_23_456.6_78f; // _ just after decimal point will give you an
								// error
	double d2 = 456_567_78.78_9;

	int bin = 0b101100011;
	byte abyte = (byte) 0b101110001011; // we have write b or B otherwise out of
										// range
	short ashort = (short) 00011101011001;

	public static void main(String[] args) {
		int six = 06; // Equal to decimal 6
		int seven = 07; // Equal to decimal 7
		int eight = 013; // Equal to decimal 8
		int nine = 011; // Equal to decimal 9
		System.out.println("Octal 010 = " + eight);

		short b = (short) 212337;
		System.out.println(b);
		float gyt = 12234567887958L;
		// float gyt = (float) 12345.6878978d; //without castng ct error
		System.out.println(gyt);
		byte b4 = 0B1111111;
		System.out.println(b4);
		byte b1 = (byte) 128;
		byte b2 = (byte) 129;
		byte b3 = (byte) -129;
		int a = 2_12_3;
		int i1 = 015237;
		byte bye = (byte) i1;
		System.out.println(i1);
		System.out.println(b1);
		System.out.println(b2);
		System.out.println(b3);
		System.out.println(bye);

		int x = 0X0001;
		int y = 0x7fffffff;
		long z = 0xDeadCafeL;
		System.out.println(x);
		System.out.println(y);
		System.out.println(z);

		long jo = 110599L;
		long so = 0xFfL;
		System.out.println(jo);
		System.out.println(so);
		int r = 0b1010;
		System.out.println(r);
		int d = (int) 113011264785798050.87474;
		double d1 = 985547874549124567.325d;// optional
		double d7 = 234567l;
		long l10 = (long) 345670987654d;
		System.out.println(d7);
		System.out.println(l10);
		System.out.println(d);

		char a1 = '\u007A';
		char b11 = '@';
		System.out.println(a1);
		System.out.println(b11);

		short i = (short) 5462215152151987f;
		System.out.println(i);

		char c = 0x892; // hexadecimal literal
		char h = 97; // int literal
		char p = (char) 70000; // The cast is required; 70000 is
		// out of char range
		char j = (char) -98;
		System.out.println(c);
		System.out.println(h);
		System.out.println(p);
		System.out.println(j);

		char quote = '\r'; // A double quote
		char new1 = '\n'; // A newline
		char tab = '\t'; // A tab
		System.out.println(quote);

		byte a11 = 3; // No problem, 3 fits in a byte
		byte b111 = 8; // No problem, 8 fits in a byte
		byte c1 = (byte) (a11 + b111);
		System.out.println(c1);

		float flow = 67867.09f;
		short show = (short) flow;
		System.out.println(show);

		byte m = 3;
		m += 7;
		
		//or
		
		byte v  = 3;
		v = (byte) (v+5);
		System.out.println(v);
		System.out.println(m);
		
		int in = 10; // Assign a value to a
		System.out.println("a = " + in);
		int bv = in;
		bv = 30;
		System.out.println("a = " + in + " after change to b");
		
		
		

	}

}
