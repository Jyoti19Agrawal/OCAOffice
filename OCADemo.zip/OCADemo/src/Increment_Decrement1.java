  
public class Increment_Decrement1 {

	static int players = 0;
	static int x =2;

	public static void main(String[] args) {
		System.out.println("players online: " + players++);
		System.out.println("The value of players is " + players);
		System.out.println("The value of players is now " + ++players);

		int x = 2;// if we will use final it will give CT error
		int y = 3;
		int z = --x
				;
		/*
		 * if ((y == x++) | (x < ++y)) { System.out.println("x = " + x + " y = "
		 * + y); System.out.println(++y); }
		 */
	 
		System.out.println(--x
				);
		
		int sizeOfYard = 10;
		int numOfPets = 3;
		String status = (numOfPets < 4) ? "Pet limit not exceeded"
				: "too many pets";
		String status1 = (numOfPets<4)?"Pet count OK"
				:(sizeOfYard > 8)? "Pet limit on the edge"
				:"too many pets";
				System.out.println("Pet status is " + status1);
		System.out.println("This pet status is " + status);
		
		byte b1 = 6 & 8;
		byte b2 = 7 | 9;
		byte b3 = 5 ^ 4;
		System.out.println(b1 + " " + b2 + " " + b3);
	}

}
