 

import java.util.Date;

public class CheckGC {
	public static void main(String[] args) {
		
		byte b1 = 6 & 8;
		byte b2 = 7 | 9;
		byte b3 = 5 ^ 4;
		int a=7,b=8,c=9;
		System.out.println(b1 + " " + b2 + " " + b3);
		int z = 5;
		//z *= 2 + 3;
		z = z * 2 + 3;
		System.out.println(z);
		if(++z > 5 || ++z > 6) z++;
		System.out.println(z);
			
		int z1 = 5;
		if(++z1 > 5 | ++z1 > 6) z1++;
		System.out.println(z1);
		
		boolean t = true;
		boolean f = true;
		System.out.println("! " + (!t ^ !f) + " " + f);
		
		
		/*Runtime rt = Runtime.getRuntime();
		System.out.println("Total JVM memory: " + rt.totalMemory());
		System.out.println("Before Memory = " + rt.freeMemory());
		Date d = null;
		for (int i = 0; i < 10; i++) {
			d = new Date();
			d = null;
			System.out.println("After Memory = " + rt.freeMemory());
			rt.gc(); // an alternate to System.gc()
			System.out.println("After GC Memory = " + rt.freeMemory());
			 
		}
		System.out.println("After Memory = " + rt.freeMemory());
		rt.gc(); // an alternate to System.gc()
		System.out.println("After GC Memory = " + rt.freeMemory());
*/	}
}