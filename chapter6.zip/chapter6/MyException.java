package com.cg.chapter6;

class MyException extends Exception {
	void someMethod() {
		try {
			doStuff();
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void doStuff() throws MyException {
		try {
			System.out.println("Hello");
			throw new MyException();
		} catch (MyException me) {
			throw me;
		}
	}
	
	public static void main(String[] args) {
		MyException mye=new MyException();
		mye.someMethod();
	}
}