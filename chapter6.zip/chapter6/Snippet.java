package com.cg.chapter6;

public class Snippet {
	int parseInt(String s) throws NumberFormatException {
	boolean parseSuccess = false;
	int result = 0;
	// do complicated parsing
	if (parseSuccess) // if the parsing failed
	throw new NumberFormatException();
	System.out.println("Handled");
	return result;
	
	}
	
	void setTitle(String title) throws IllegalArgumentException
	{
		System.out.println("Title");
	}
	public static void main(String[] args) {
		Snippet s =new Snippet();
		s.parseInt("Jyoti");
		s.setTitle("asdfg");
	}
}

