package com.cg.chapter6;

import java.io.IOException;

public class ThrowDemo {
	public void method1() throws IOException {
		System.out.println("I am method1 of ThrowDemo");
		try{method2();}
		catch (IOException ie) {
			ie.printStackTrace();
			// System.out.println("Invalid");
			throw ie;
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		finally{
			System.out.println("Resource closed");
		}
	}

	public void method2() throws IOException {
		System.out.println("I am method2 of ThrowDemo");
		throw new IOException("Message");
		/*
		 * try { throw new IOException(); } catch(IOException ie) {
		 * ie.printStackTrace(); }
		 */
	}

	public static void main(String[] args){
		ThrowDemo tt = new ThrowDemo();

		// tt.method2();
		// tt.method1();
	
			try {
				tt.method1();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

	}
}
