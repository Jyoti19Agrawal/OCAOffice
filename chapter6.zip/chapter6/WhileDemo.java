package com.cg.chapter6;

public class WhileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 8;
		while(x <15)
		{
			System.out.println(x);
			//System.exit(x);
			/*while(x==9)
				break;
		*/
			x++;
		}
		System.out.println("Break");
		
		do {
			System.out.println("Inside loop");
			} while(x == 9);
		
	}

}
