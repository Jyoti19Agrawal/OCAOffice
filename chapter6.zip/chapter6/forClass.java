package com.cg.chapter6;


class Animal
{
	}
class Dog extends Animal {}
class Cat extends Dog {}
public class forClass {

	static void doStuff()
	{
		System.out.println("Inside the method");
	}
	public static void main(String[] args) {
		
		//int i = 0;
		/*for (int i = 0 , p = 0; ((((i < 10) && (i-- > 0)) | i == 3)); i++ , p++) {
			System.out.println("i is " + i);
			//System.out.println(p);
			}*/
	
		
		for(int i = 0; i<5; ++i)
		{
			System.out.println("Hello");
			doStuff();
			System.exit(0);
			//return;
		}
		System.out.println("Oustide the loop");
		
		/*for( ; i < 5; )
		{
			i++;
			System.out.println("Inside the while loop");
			
		}
		System.out.println("Outside the loop");*/
		
		/*for (int k = 0,j = 0; (k<10) && (j<10); k++, j++) {
			System.out.println("i is " + i + " j is " +j);
			}
		*/
		
		for(int p = 0,m =0, k=0; p<4 ; p++)
		{
			System.out.println("Different variable of for loop");
			continue;
		}
		
		
		int b = 3;
		for (int a = 1; b != 1; System.out.println("iterate")) {
		b = b - a;
		}
		
		int[] n = {1,2,2,4,4};
		for(int x = 0; x<n.length; x++)
		{
			System.out.print(n[x]);
		}
		System.out.println("   ");
		for (Object x : n)
		{
			System.out.println(x);
		}
		
		
		int x;
		long x2;
		long [] la = {7L, 8L, 9L};
		int [][] twoDee = {{1,2,3}, {4,5,6}, {7,8,9}};
		String [] sNums = {"one", "two", "three"};
		Animal [] animals = {new Dog(), new Cat()};
		
		for(Object o : sNums)
		{
			System.out.print(o+" ");
		}
		System.out.println("   ");
		for(int[] n1 : twoDee) 
		{
			//System.out.print(n1+" ");
			//System.out.println("   ");
			System.out.print(n1[2]+" ");
		} 
		System.out.println("   ");
		for(int n2 : twoDee[2])
		{
			
			System.out.print(n2);
			break;
		}
		System.out.print("   ");
		System.out.println("Two dimensional array");
		
		System.out.println("   ");
		for(Animal a : animals)
		{
			System.out.println(a);
			continue;
		}
		System.out.println("Animal block");
		 
	}

	
	
}
