package com.cg.chapter6;

/*class TestEx {
 public static void main(String[] args) {
 doStuff();
 System.out.println("Mainsss");
 }

 static void doStuff() {
 doMoreStuff();
 System.out.println("hello");
 }

 static void doMoreStuff() {
 int x = 5 / 1;
 System.out.println(x);// Can't divide by zero!
 // ArithmeticException is thrown here
 }
 }*/

class TestEx {
	static String s;
	public static void main(String[] args) {
		badMethod();
		System.out.println(s.toLowerCase());//NullPointerException
	}

	static void badMethod(){ // No need to declare an Error
		//doStuff();
		badMethod();
		System.out.println("badmethod");
		
	}

	/*static void doStuff() throws Error { // No need to declare an Error
		try {
			throw new Error();
		} catch (Error me) {
			throw me;// We catch it, but then rethrow it
		}
	}*/
}