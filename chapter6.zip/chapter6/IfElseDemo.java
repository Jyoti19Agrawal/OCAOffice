package com.cg.chapter6;

enum z1 {
	MON, TUES
};

public class IfElseDemo {
	private static final short someNumber = 0;

	static boolean doStuff() {
		return true;

	}

	public static void main(String[] args) {
		boolean b = false;
		int y = 5;
		int x = 1;
		if (((x > 3) && (y < 2)) | doStuff()) {
			System.out.println("true");
		}
		if (b = true) {
			System.out.println(b);
		}
		/*
		 * if(x =4)// Ct error {
		 * 
		 * }
		 */

		int x1 = 1;
		if (x1 == 1) {
			System.out.println("x equals 1");
		} else if (x1 == 2) {
			System.out.println("x equals 2");
		} else {
			System.out.println("No idea what x is");
		}

		final int a = 1;
		final int b1 = 2;
		// b1 = 2;// we cant give value of b here because b1 is final
		// int x = 0;
		switch (x1) {
		case a: // ok
			System.out.println("OK");
			break;
		default:
			System.out.println("Invalid");

		case b1:
			System.out.println("Not OK");
			break;
		/*default:
			System.out.println("Invalid");*/
		}

		switch (x1) {
		case 1:
			System.out.println("x equals 1");
			break; // without break it will print all statement
		case 2:
			System.out.println("x equals 2");
			break;
		default:
			System.out.println("No idea what x is");
		}
		int[] arr = new int[2];
	    System.out.println(arr.toString());
		String s = "teal";
		switch (s) {
		case "teal":
			System.out.println("length is one");
			break;
		default:
			System.out.println("no match");
			break;
		case "Red":
			System.out.println("length is two");
			break;
		case "pink":
			System.out.println("length is three");
			break;
		/*default:
			System.out.println("no match");*/
		}

		short g = someNumber;
		switch (g) {
		case 0:
			System.out.println("valid");
			break;
		case 12895:  //it wont compile if will give it a number 128
			System.out.println("CompilerError");
			break;
			default:
				System.out.println("Default");
				break;
		}
		
		switch(new Integer(2)) {
		case 1 : System.out.println("Case 1");break;
		case 2 : System.out.println("Case 2");break;
		case 4: System.out.println("boxing is OK");break;
		}
		System.out.println("Bahar aagye");
		
		
		String month = null;
		char c= 'J';
		switch(c)
		{
		case 'a' :
			month = "January";
			break;
		case 'J' : 
			month = "December";
			break;
		}
		System.out.println(month);
	}

}
