package com.cg.chapter6;

public class ExceptionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			int a[] = new int[5];
			a[5] = 30 / 1;
			System.out.println("success.....");
			System.exit(1);
		} 
		catch (ArrayIndexOutOfBoundsException | ArithmeticException e) {
			System.out.println("task 2 completed");
			System.exit(1);
		}
		/*catch (ArithmeticException e) {
			System.out.println("task1 is completed");
			//e.printStackTrace();
			//System.out.println(e.getMessage());
			System.exit(1);
		} */ catch (Exception e) {
			System.out.println("common task completed");
		}

		finally{
			System.out.println("finally block is always executed");
		}
		System.out.println("rest of the code...");
	}

	// System.out.println("rest of the code...");

}
