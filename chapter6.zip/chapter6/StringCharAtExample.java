package com.cg.chapter6;
public class StringCharAtExample {
	public static void main(String[] args) {
		String str = "Java Code Geeks!";
		char ch = str.charAt(8);
		System.out.println(ch);
		System.out.println("Length: " + str.length());
		
		//The following statement throws an exception, because
		//the request index is invalid.
		
		
		String str1= "Java Code Geeks!";
		System.out.println("Length: " + str1.length());
		
		//The following statement throws an exception, because
		//the request index is invalid.
		CharSequence seq = str1.subSequence(5, 10);
		System.out.println(seq);

		
	}
}